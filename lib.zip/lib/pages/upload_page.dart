import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class UploadPage extends StatefulWidget {
  const UploadPage({super.key});

  @override
  State<UploadPage> createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  File? _selectedFile;
  bool _isVideo = false;

  @override
  void initState() {
    super.initState();
    _pickMediaFromCamera(); // Otomatis buka kamera saat halaman masuk
  }

  Future<void> _pickMediaFromCamera() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _selectedFile = File(pickedFile.path);
        _isVideo = false;
      });
    }
  }

  Future<void> _pickMediaFromGallery(bool isVideo) async {
    final picker = ImagePicker();
    XFile? pickedFile;
    if (isVideo) {
      pickedFile = await picker.pickVideo(source: ImageSource.gallery);
    } else {
      pickedFile = await picker.pickImage(source: ImageSource.gallery);
    }
    if (pickedFile != null) {
      setState(() {
        _selectedFile = File(pickedFile!.path);
        _isVideo = isVideo;
      });
    }
  }

  Future<void> _uploadToSupabase() async {
    if (_selectedFile == null) return;
    try {
      final supabase = Supabase.instance.client;
      final user = supabase.auth.currentUser;
      if (user == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Anda belum login')),
        );
        return;
      }

      // Buat nama file unik berdasarkan timestamp
      final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
      final extension = _isVideo ? '.mp4' : '.jpg';
      final fileName = 'uploads/$timestamp$extension';

      // Upload file ke bucket 'rm_gallery'
      await supabase.storage.from('rm_gallery').upload(fileName, _selectedFile!);

      // Dapatkan public URL (asumsi bucket sudah disetting public)
      final publicUrl = supabase.storage.from('rm_gallery').getPublicUrl(fileName).data!;

      if (_isVideo) {
        // Simpan metadata ke tabel gallery_video
        await supabase.from('gallery_video').insert({
          'id_album': null, // Isi jika ada album tertentu
          'nama_video': 'Video $timestamp',
          'keterangan_video': 'Keterangan ...',
          'video_url': publicUrl,
        });
      } else {
        // Simpan metadata ke tabel gallery_image
        await supabase.from('gallery_image').insert({
          'id_album': null,
          'nama_foto': 'Foto $timestamp',
          'keterangan_foto': 'Keterangan ...',
          'image_url': publicUrl,
        });
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Upload berhasil!')),
      );
      Navigator.pop(context); // Kembali ke halaman sebelumnya
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Tidak ada bottom navigation bar di halaman ini
      appBar: AppBar(
        title: const Text('Upload Media'),
      ),
      body: Column(
        children: [
          Expanded(
            child: _selectedFile == null
                ? const Center(child: Text('No media selected.'))
                : _isVideo
                    ? Center(child: Text('Video selected: ${_selectedFile!.path}'))
                    : Image.file(_selectedFile!, fit: BoxFit.cover),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // Tombol untuk membuka kamera lagi
                ElevatedButton(
                  onPressed: _pickMediaFromCamera,
                  child: const Text('Upload'),
                ),
                // Tombol untuk memilih dari galeri
                ElevatedButton(
                  onPressed: () {
                    showModalBottomSheet(
                      context: context,
                      builder: (_) => SafeArea(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ListTile(
                              leading: const Icon(Icons.photo),
                              title: const Text('Ambil Foto dari Galeri'),
                              onTap: () {
                                Navigator.pop(context);
                                _pickMediaFromGallery(false);
                              },
                            ),
                            ListTile(
                              leading: const Icon(Icons.video_collection),
                              title: const Text('Ambil Video dari Galeri'),
                              onTap: () {
                                Navigator.pop(context);
                                _pickMediaFromGallery(true);
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                  child: const Text('Album'),
                ),
                // Tombol untuk menyimpan/upload file ke Supabase
                ElevatedButton(
                  onPressed: _uploadToSupabase,
                  child: const Text('Simpan'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

extension on String {
  get data => null;
}
