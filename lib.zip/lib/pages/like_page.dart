import 'package:flutter/material.dart';

class LikePage extends StatelessWidget {
  const LikePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text('Liked Posts'),
      ),
      body: const Center(
        child: Text('Daftar Postingan yang Disukai'),
      ),
    );
  }
}