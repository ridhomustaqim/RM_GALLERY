import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Log Out'),
            onTap: () {
              // Logika logout
              _logout(context);
            },
          ),
        ],
      ),
    );
  }

  void _logout(BuildContext context) {
    // Contoh: Hapus session atau reset state
    // Misalnya, Anda bisa menggunakan Provider atau state management lainnya

    // Tampilkan dialog konfirmasi
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Log Out'),
          content: const Text('Are you sure you want to log out?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Tutup dialog
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                // Lakukan logout
                Navigator.pop(context); // Tutup dialog
                Navigator.pushReplacementNamed(context, '/login'); // Kembali ke halaman login
              },
              child: const Text('Log Out'),
            ),
          ],
        );
      },
    );
  }
}