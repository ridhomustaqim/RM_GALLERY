import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'profile_page.dart';
import 'like_page.dart';
import 'search_page.dart';
import 'upload_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  bool _isLoading = true;
  List<Map<String, dynamic>> _mediaList = [];
  
  @override
  void initState() {
    super.initState();
    _fetchMedia();
  }
  
  Future<void> _fetchMedia() async {
    final supabase = Supabase.instance.client;
    try {
      // Query untuk 10 foto terbaru
      final imageResponse = await supabase
          .from('gallery_image')
          .select('image_url, nama_foto, created_at')
          .order('created_at', ascending: false)
          .limit(10);
      // Query untuk 10 video terbaru
      final videoResponse = await supabase
          .from('gallery_video')
          .select('video_url, nama_video, created_at')
          .order('created_at', ascending: false)
          .limit(10);
  
      List<Map<String, dynamic>> combined = [];
      if (imageResponse.data != null) {
        for (var img in imageResponse.data as List<dynamic>) {
          combined.add({
            'type': 'image',
            'url': img['image_url'],
            'name': img['nama_foto'],
            'created_at': img['created_at'],
          });
        }
      }
      if (videoResponse.data != null) {
        for (var vid in videoResponse.data as List<dynamic>) {
          combined.add({
            'type': 'video',
            'url': vid['video_url'],
            'name': vid['nama_video'],
            'created_at': vid['created_at'],
          });
        }
      }
      // Urutkan berdasarkan created_at descending
      combined.sort((a, b) {
        DateTime dateA = DateTime.parse(a['created_at']);
        DateTime dateB = DateTime.parse(b['created_at']);
        return dateB.compareTo(dateA);
      });
      // Ambil 10 item teratas (gabungan)
      combined = combined.take(10).toList();
  
      setState(() {
        _mediaList = combined;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Error fetching media: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  /// Widget tampilan Home dengan header photoprofile dan ikon search
  Widget _buildHomeContent() {
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          // Header dengan photoprofile dan search icon
          SliverAppBar(
            floating: true,
            automaticallyImplyLeading: false,
            leading: Container(
              margin: const EdgeInsets.only(left: 16),
              height: 40,
              width: 40,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                  image: AssetImage('assets/images/rm_gallery.png'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            centerTitle: false,
            title: const SizedBox.shrink(),
            actions: [
              IconButton(
                icon: const Icon(Icons.search),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SearchPage()),
                  );
                },
              ),
            ],
          ),
          // Grid view media
          SliverPadding(
            padding: const EdgeInsets.all(8),
            sliver: _isLoading
                ? SliverFillRemaining(
                    child: const Center(child: CircularProgressIndicator()),
                  )
                : _mediaList.isEmpty
                    ? SliverFillRemaining(
                        child: const Center(child: Text('No media available')),
                      )
                    : SliverGrid(
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                        ),
                        delegate: SliverChildBuilderDelegate(
                          (context, index) {
                            final media = _mediaList[index];
                            return GestureDetector(
                              onTap: () {
                                // Navigasi ke detail media jika diinginkan
                              },
                              child: Card(
                                clipBehavior: Clip.antiAlias,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    media['type'] == 'image'
                                        ? Image.network(
                                            media['url'],
                                            fit: BoxFit.cover,
                                          )
                                        : Container(
                                            color: Colors.black12,
                                            child: const Center(
                                              child: Icon(
                                                Icons.play_circle_fill,
                                                size: 50,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                    Positioned(
                                      bottom: 4,
                                      left: 4,
                                      right: 4,
                                      child: Container(
                                        color: Colors.black54,
                                        padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 4),
                                        child: Text(
                                          media['name'] ?? '',
                                          style: const TextStyle(color: Colors.white, fontSize: 12),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                          childCount: _mediaList.length,
                        ),
                      ),
          ),
        ],
      ),
    );
  }
  
  /// Memilih tampilan konten berdasarkan _selectedIndex
  Widget _buildContent() {
    if (_selectedIndex == 0) {
      return _buildHomeContent();
    } else if (_selectedIndex == 1) {
      return const SearchPage();
    } else if (_selectedIndex == 3) {
      return const LikePage();
    } else if (_selectedIndex == 4) {
      return const ProfilePage();
    }
    return _buildHomeContent();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildContent(),
      bottomNavigationBar: CurvedNavigationBar(
        index: _selectedIndex,
        items: const [
          Icon(Icons.home, size: 30),
          Icon(Icons.search, size: 30),
          Icon(Icons.add_box_outlined, size: 30),
          Icon(Icons.favorite, size: 30),
          Icon(Icons.person, size: 30),
        ],
        onTap: (index) {
          if (index == 2) {
            // Tombol upload: buka UploadPage
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const UploadPage()),
            );
          } else {
            setState(() {
              _selectedIndex = index;
            });
          }
        },
        height: 60.0,
        color: Colors.blue,
        buttonBackgroundColor: Colors.blue,
        backgroundColor: Colors.transparent,
        animationDuration: const Duration(milliseconds: 300),
      ),
    );
  }
}

extension on PostgrestList {
  get data => null;
}
