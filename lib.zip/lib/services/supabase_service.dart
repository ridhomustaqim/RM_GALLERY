import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../utils/constants.dart';

class SupabaseService {
  final SupabaseClient _supabase = SupabaseClient(supabaseUrl, supabaseAnonKey);

  /// Fungsi SignUp dengan param [username], [namaLengkap], [email], [password].
  /// 1) Membuat akun di Supabase Auth (email + password).
  /// 2) Jika sukses, insert data tambahan ke tabel "gallery_users".
  Future<AuthResponse> signUp({
    required String username,
    required String namaLengkap,
    required String email,
    required String password,
  }) async {
    // 1) Buat akun di Supabase Auth
    final response = await _supabase.auth.signUp(
      email: email,
      password: password,
    );

    // 2) Jika sukses, insert data tambahan ke "gallery_users"
    if (response.user != null) {
      final userId = response.user!.id; // ID user dari Supabase Auth
      // Insert ke tabel "gallery_users"
      // Pastikan kolom di DB: id_user, username, nama_lengkap, email, password
      await _supabase.from('gallery_users').insert({
        'id_user': userId,
        'username': username,
        'nama_lengkap': namaLengkap,
        'email': email,
        'password': password, // plaintext, disarankan hashing untuk production
      });
    }
    return response; // Kembalikan AuthResponse
  }

  /// Fungsi SignIn (email + password) menggunakan Supabase Auth
  Future<AuthResponse> signIn(String email, String password) async {
    return await _supabase.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  /// Fungsi Logout
  Future<void> signOut() async {
    await _supabase.auth.signOut();
  }

  /// Ambil Data Album Berdasarkan User (Contoh)
  Future<List<Map<String, dynamic>>> getAlbums() async {
    final user = _supabase.auth.currentUser;
    if (user == null) return [];
    final response = await _supabase
        .from('gallery_album')
        .select()
        .eq('id_user', user.id)
        .order('created_at', ascending: false);

    // response.data -> List<dynamic>, kita konversi ke List<Map<String, dynamic>>
    if (response.error != null || response.data == null) {
      return [];
    }
    return List<Map<String, dynamic>>.from(response.data as List);
  }

  /// Upload Gambar ke Supabase Storage (Contoh)
  Future<String?> uploadImage(String filePath, String fileName) async {
    try {
      final file = File(filePath);
      await _supabase.storage.from('rm_gallery').upload(fileName, file);

      // Dapatkan public URL
      final publicUrlRes = _supabase.storage.from('rm_gallery').getPublicUrl(fileName);
      return publicUrlRes; // publicUrl string
    } catch (e) {
      return null;
    }
  }
}

extension on PostgrestList {
  get data => null;   
  get error => null;
}
